// Compare.c

#include "head.h"
char l = '>';
char r = '<';
char e = '=';

char compareS(int a, int b) {

if(a>b) return l;
else if(a<b) return r;
else return e;

}

char compareU(unsigned int c ,unsigned int d){

if(c>d) return l;
else if(c<d) return r;
else return e;
}      
