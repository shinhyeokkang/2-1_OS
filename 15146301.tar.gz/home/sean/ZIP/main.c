// main.c

#include "head.h"

void main(){
printf("0 %c 0U\n",compareU(0,0U));
printf("-1 %c 0\n",compareS(-1,0));
printf("-1 %c 0U\n",compareU(-1,0U));
printf("2147483647 %c -2147483647-1\n",compareS(2147483647,-2147483647-1));
printf("2147483647U %c -2147483647-1\n",compareU(2147483647U,-2147483647-1));
printf("-1 %c -2\n",compareS(-1,-2));
printf("(unsigned)-1 %c -2\n",compareU((unsigned)-1,-2));
printf("2147483647 %c 2147483648U\n",compareU(2147483647,2147483648U));
printf("2147483647 %c(int)2147483648U\n",compareS(2147483647,(int)2147483648U));
}      
