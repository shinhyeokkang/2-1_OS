// head.h

#include <stdio.h>
void main();
void compare();
